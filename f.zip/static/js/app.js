setTimeout(()=>document.querySelectorAll('.toast').forEach(x=>{x.style.opacity='0';x.style.transition='.5s';setTimeout(()=>x.remove(),500)}),4500);
document.querySelectorAll('input[type=file]').forEach(i=>i.addEventListener('change',()=>{if(i.files[0]&&i.files[0].size>8*1024*1024)alert('Maximum upload size is 8 MB.')}));
document.addEventListener("DOMContentLoaded",()=>{
  const loader=document.getElementById("page-loader");
  setTimeout(()=>loader?.classList.add("hidden"),450);
  document.querySelectorAll("a[href]").forEach(a=>{
    if(a.target==="_blank"||a.href.startsWith("javascript:")||a.href.includes("#")) return;
    a.addEventListener("click",()=>loader?.classList.remove("hidden"));
  });
  document.querySelectorAll(".copy-btn").forEach(btn=>{
    btn.addEventListener("click",async()=>{
      try{await navigator.clipboard.writeText(btn.dataset.copy||"");const old=btn.textContent;btn.textContent="Copied ✓";btn.classList.add("copied");setTimeout(()=>{btn.textContent=old;btn.classList.remove("copied")},1400)}
      catch(e){alert("Copy failed. Please copy it manually.")}
    });
  });
});
window.addEventListener("pageshow",()=>document.getElementById("page-loader")?.classList.add("hidden"));

# PrimeCloud Website

## Setup
1. Install dependencies from `requirements.txt`.
2. Set `SECRET_KEY`, `ADMIN_USERNAME`, `ADMIN_EMAIL`, and `ADMIN_PASSWORD`.
3. Run `python3 website.py`.
4. Register normally; no email verification is required.

## Plans
Admins can create/edit plans, select one of the built-in categories, and set Stock / Out of Stock. Customers choose a category from the plans-page select menu.

## VPS verification
VPS orders can require the built-in abuse-prevention verification form before payment. The panel stores only the limited account/verification information needed for review. Do not store raw Aadhaar documents, full card numbers, or CVV.

## Payment
Use a PCI-compliant hosted payment gateway. Store only payment/order status and gateway transaction identifiers.
